package com.smartsociety.hub;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.*;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends AppCompatActivity {
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private WebView web;
    private FrameLayout root;
    private View splash;
    private ValueCallback<Uri[]> filePathCallback;
    private PermissionRequest pendingPerm;
    private ActivityResultLauncher<Intent> fileLauncher;
    private ActivityResultLauncher<String> camLauncher;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#F97316"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // Native splash: identical to the window background, stays until the web app says it is ready
        FrameLayout sp = new FrameLayout(this);
        sp.setBackgroundColor(Color.parseColor("#F97316"));
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_fg);
        float d = getResources().getDisplayMetrics().density;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) (120 * d), (int) (120 * d));
        lp.gravity = android.view.Gravity.CENTER;
        sp.addView(logo, lp);
        splash = sp;
        root.addView(splash, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        new Handler(Looper.getMainLooper()).postDelayed(this::hideSplash, 12000); // safety fallback
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets sb = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            v.setPadding(sb.left, sb.top, sb.right, Math.max(sb.bottom, ime.bottom));
            return insets;
        });

        fileLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            Uri[] res = null;
            if (r.getResultCode() == Activity.RESULT_OK && r.getData() != null)
                res = WebChromeClient.FileChooserParams.parseResult(r.getResultCode(), r.getData());
            if (filePathCallback != null) filePathCallback.onReceiveValue(res);
            filePathCallback = null;
        });
        camLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), ok -> {
            if (pendingPerm != null) { if (ok) pendingPerm.grant(pendingPerm.getResources()); else pendingPerm.deny(); }
            pendingPerm = null;
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage -> login session & data persist
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("https://appassets.androidplatform.net")) return false;
                if (u.startsWith("tel:") || u.startsWith("mailto:") || u.startsWith("sms:") || u.startsWith("http")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) {}
                    return true;
                }
                return false;
            }
            @Override public void onPageFinished(WebView v, String url) {
                // window.print() is not available in WebView by default -> route to Android print service
                v.evaluateJavascript("window.print=function(){Android.print()};", null);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        req.grant(req.getResources());
                    } else { pendingPerm = req; camLauncher.launch(Manifest.permission.CAMERA); }
                });
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try { fileLauncher.launch(p.createIntent()); } catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
        });
        web.setDownloadListener((url, ua, cd, mime, len) -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) {}
        });
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void exitApp() { runOnUiThread(() -> finishAndRemoveTask()); }   // closes the app, session stays
            @JavascriptInterface public void closeApp() { exitApp(); }
            @JavascriptInterface public void appReady() { runOnUiThread(() -> hideSplash()); }
            @JavascriptInterface public void print() {
                runOnUiThread(() -> {
                    PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                    pm.print("document", web.createPrintDocumentAdapter("document"), new PrintAttributes.Builder().build());
                });
            }
        }, "Android");

        // Back button / back gesture -> handled by the web app (previous screen, then exit confirmation)
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                web.evaluateJavascript("(function(){try{window.handleAndroidBack();return 1}catch(e){return 0}})()", v -> {
                    if ("0".equals(v)) finish();
                });
            }
        });

        if (b == null) web.loadUrl(HOME); else web.restoreState(b);
    }

    private void hideSplash() {
        if (splash != null && splash.getParent() == root) { root.removeView(splash); }
        splash = null;
    }

    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); web.saveState(o); }
    @Override protected void onPause() { super.onPause(); web.onPause(); CookieManager.getInstance().flush(); } // minimize keeps login
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }
}
