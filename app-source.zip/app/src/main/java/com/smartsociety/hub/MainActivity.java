package com.smartsociety.hub;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.*;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.webkit.WebViewAssetLoader;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private WebView web;
    private WebView printWeb;
    private FrameLayout root;
    private View splash;
    private ValueCallback<Uri[]> filePathCallback;
    private PermissionRequest pendingPerm;
    private ActivityResultLauncher<Intent> fileLauncher;
    private ActivityResultLauncher<Intent> contactLauncher;
    private ActivityResultLauncher<String> camLauncher;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#F97316"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Native splash: identical to the window background, stays until the web app says it is ready
        FrameLayout sp = new FrameLayout(this);
        sp.setBackgroundColor(Color.parseColor("#F97316"));
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_fg);
        float d = getResources().getDisplayMetrics().density;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) (120 * d), (int) (120 * d));
        lp.gravity = Gravity.CENTER;
        sp.addView(logo, lp);
        splash = sp;
        root.addView(splash, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        new Handler(Looper.getMainLooper()).postDelayed(this::hideSplash, 12000); // safety fallback
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets sb = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            v.setPadding(sb.left, sb.top, sb.right, Math.max(sb.bottom, ime.bottom));
            return insets;
        });

        fileLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            Uri[] res = null;
            if (r.getResultCode() == Activity.RESULT_OK && r.getData() != null)
                res = WebChromeClient.FileChooserParams.parseResult(r.getResultCode(), r.getData());
            if (filePathCallback != null) filePathCallback.onReceiveValue(res);
            filePathCallback = null;
        });
        camLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), ok -> {
            if (pendingPerm != null) { if (ok) pendingPerm.grant(pendingPerm.getResources()); else pendingPerm.deny(); }
            pendingPerm = null;
        });
        // Device contact picker (no READ_CONTACTS permission needed: only the picked contact is shared)
        contactLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            String name = "", number = "";
            try {
                if (r.getResultCode() == Activity.RESULT_OK && r.getData() != null && r.getData().getData() != null) {
                    Cursor c = getContentResolver().query(r.getData().getData(),
                            new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME},
                            null, null, null);
                    if (c != null) {
                        if (c.moveToFirst()) { number = c.getString(0); name = c.getString(1); }
                        c.close();
                    }
                }
            } catch (Exception e) { /* ignore */ }
            final String js = "window.__scContactResult&&window.__scContactResult("
                    + JSONObject.quote(name == null ? "" : name) + "," + JSONObject.quote(number == null ? "" : number) + ")";
            web.evaluateJavascript(js, null);
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage -> login session & data persist
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK); // reuse cached CDN files -> faster start
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("https://appassets.androidplatform.net")) return false;
                if (u.startsWith("tel:") || u.startsWith("mailto:") || u.startsWith("sms:") || u.startsWith("http")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) {}
                    return true;
                }
                return false;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        req.grant(req.getResources());
                    } else { pendingPerm = req; camLauncher.launch(Manifest.permission.CAMERA); }
                });
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try { fileLauncher.launch(p.createIntent()); } catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
        });
        web.setDownloadListener((url, ua, cd, mime, len) -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) {}
        });
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void exitApp() { runOnUiThread(() -> finishAndRemoveTask()); }   // closes the app, session stays
            @JavascriptInterface public void closeApp() { exitApp(); }
            @JavascriptInterface public void appReady() { runOnUiThread(() -> hideSplash()); }
            @JavascriptInterface public void pickContact() {
                runOnUiThread(() -> {
                    try {
                        contactLauncher.launch(new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI));
                    } catch (Exception e) {
                        web.evaluateJavascript("window.__scContactResult&&window.__scContactResult('','')", null);
                        toast("কন্টাক্ট অ্যাপ খোলা যায়নি");
                    }
                });
            }
            @JavascriptInterface public void saveBase64(String b64, String name, String mime) { saveFile(b64, name, mime); }
            @JavascriptInterface public void printHtml(final String html, final String title) { runOnUiThread(() -> printHtmlDoc(html, title)); }
            @JavascriptInterface public void print() { runOnUiThread(() -> printWebView(web, "document")); }
        }, "Android");

        // Back button / back gesture -> handled by the web app (previous screen, then exit confirmation)
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                web.evaluateJavascript("(function(){try{window.handleAndroidBack();return 1}catch(e){return 0}})()", v -> {
                    if ("0".equals(v)) finish();
                });
            }
        });

        if (b == null) web.loadUrl(HOME); else web.restoreState(b);
    }

    private void toast(final String m) { runOnUiThread(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show()); }

    /** Saves a file (card image, QR, PDF, backup ...) into the phone's Downloads folder. */
    private void saveFile(String b64, String name, String mime) {
        try {
            byte[] data = Base64.decode(b64, Base64.DEFAULT);
            String fn = (name == null || name.trim().isEmpty()) ? "file" : name.replaceAll("[\\\\/:*?\"<>|]", "_");
            String mt = mime;
            if (mt == null || mt.isEmpty()) {
                String ext = MimeTypeMap.getFileExtensionFromUrl(fn);
                mt = ext == null ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase());
                if (mt == null) mt = "application/octet-stream";
            }
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, fn);
                cv.put(MediaStore.Downloads.MIME_TYPE, mt);
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) throw new Exception("insert failed");
                OutputStream os = getContentResolver().openOutputStream(uri);
                os.write(data); os.close();
                toast("ডাউনলোড ফোল্ডারে সংরক্ষিত হয়েছে: " + fn);
            } else {
                File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                File f = new File(dir, fn);
                FileOutputStream fo = new FileOutputStream(f);
                fo.write(data); fo.close();
                toast("সংরক্ষিত হয়েছে: " + f.getAbsolutePath());
            }
        } catch (Exception e) {
            toast("ফাইল সংরক্ষণ করা যায়নি");
        }
    }

    /** Prints a clean HTML copy of the page through a hidden WebView (no impact on the app screen). */
    private void printHtmlDoc(final String html, final String title) {
        try {
            if (isFinishing()) return;
            if (printWeb != null) { try { printWeb.destroy(); } catch (Exception e) {} printWeb = null; }
            final WebView pw = new WebView(this);
            printWeb = pw;
            pw.getSettings().setJavaScriptEnabled(false);
            pw.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(final WebView v, String url) {
                    new Handler(Looper.getMainLooper()).postDelayed(() -> printWebView(v, title), 900);
                }
            });
            pw.loadDataWithBaseURL(HOME, html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            toast("প্রিন্ট শুরু করা যায়নি");
        }
    }

    private void printWebView(WebView v, String title) {
        try {
            if (isFinishing()) return;
            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
            String job = (title == null || title.trim().isEmpty()) ? "document" : title;
            PrintDocumentAdapter ad = v.createPrintDocumentAdapter(job);
            pm.print(job, ad, new PrintAttributes.Builder().build());
        } catch (Exception e) {
            toast("প্রিন্ট শুরু করা যায়নি");
        }
    }

    private void hideSplash() {
        if (splash != null && splash.getParent() == root) { root.removeView(splash); }
        splash = null;
    }

    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); web.saveState(o); }
    @Override protected void onPause() { super.onPause(); web.onPause(); CookieManager.getInstance().flush(); } // minimize keeps login
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override protected void onDestroy() { if (printWeb != null) printWeb.destroy(); if (web != null) web.destroy(); super.onDestroy(); }
}
